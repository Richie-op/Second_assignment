public class MainImpl extends Main {
}
